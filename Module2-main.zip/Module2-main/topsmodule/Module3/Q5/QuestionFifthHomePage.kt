package com.example.topsmodule.Module3.Q5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.topsmodule.R

class QuestionFifthHomePage : AppCompatActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_question_fifth_home_page)
    }
}